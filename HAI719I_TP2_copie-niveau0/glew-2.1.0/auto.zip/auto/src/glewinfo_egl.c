}

#elif defined(GLEW_EGL)

static void eglewInfo ()
{
